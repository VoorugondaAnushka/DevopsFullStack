import React, { useEffect, useState } from "react";

const mockApiUrl = "https://shryitha.github.io/DevOps1/abc.json";

function StudentProfileHooks() {
  const [student, setStudent] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    console.log("Hooks Mounted");

    fetch(mockApiUrl)
      .then(res => res.json())
      .then(data => {
        setStudent(data);
        setLoading(false);
      });

    return () => {
      console.log("Hooks Unmounted");
    };
  }, []);

  useEffect(() => {
    if (student) console.log("Hooks Updated");
  }, [student]);

  return (
    <div>
      <h2>Hooks Version</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <>
          <p>Name: {student.name}</p>
          <p>Email: {student.email}</p>
          <p>Phone: {student.phone}</p>
        </>
      )}
    </div>
  );
}

export default StudentProfileHooks;