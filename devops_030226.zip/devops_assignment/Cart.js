import React, { useState } from "react";
import CartItem from "./CartItem";

function Cart() {
  const [quantity, setQuantity] = useState(1);

  const incrementQuantity = () => {
    setQuantity(quantity + 1);
  };

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const resetQuantity = () => {
    setQuantity(1);
  };

  return (
    <div
      style={{
        textAlign: "center",
        marginTop: "50px",
        backgroundColor: "#f0f8ff",
        minHeight: "100vh",
        padding: "20px",
      }}
    >
      <h1>Shopping Cart</h1>

      {/* FLEX CONTAINER */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: "20px",
          flexWrap: "wrap",
        }}
      >
        <CartItem
  productName="Laptop"
  quantity={quantity}
  increment={incrementQuantity}
  decrement={decrementQuantity}
  reset={resetQuantity}
/>

<CartItem
  productName="Smartphone"
  quantity={quantity}
  increment={incrementQuantity}
  decrement={decrementQuantity}
  reset={resetQuantity}
/>

<CartItem
  productName="Headphones"
  quantity={quantity}
  increment={incrementQuantity}
  decrement={decrementQuantity}
  reset={resetQuantity}
/>

<CartItem
  productName="Keyboard"
  quantity={quantity}
  increment={incrementQuantity}
  decrement={decrementQuantity}
  reset={resetQuantity}
/>

<CartItem
  productName="Mouse"
  quantity={quantity}
  increment={incrementQuantity}
  decrement={decrementQuantity}
  reset={resetQuantity}
/>

      </div>
    </div>
  );
}

export default Cart;
