import React, { useState } from "react";
import CartItem from "./CartItem";
function Cart() {
  const [items, setItems] = useState([
    { id: 1, name: "Headphones", price: 50, quantity: 0 },
    { id: 2, name: "Smart Watch", price: 100, quantity: 0 },
    { id: 3, name: "Bluetooth Speaker", price: 80, quantity: 0 },
    { id: 4, name: "Laptop", price: 150, quantity: 0 },
    { id: 5, name: "Keyboard", price: 70, quantity: 0 },
    { id: 6, name: "Mouse", price: 60, quantity: 0 },
    { id: 7, name: "Tablet", price: 150, quantity: 0 },
    { id: 8, name: "Monitor", price: 200, quantity: 0 },
    { id: 9, name: "Webcam", price: 40, quantity: 0 }
  ]);
  const increment = (id) => {
    setItems(
      items.map((item) =>
        item.id === id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      )
    );
  };

  const decrement = (id) => {
    setItems(
      items.map((item) =>
        item.id === id && item.quantity > 0
          ? { ...item, quantity: item.quantity - 1 }
          : item
      )
    );
  };

  const resetItem = (id) => {
    setItems(
      items.map((item) =>
        item.id === id ? { ...item, quantity: 0 } : item
      )
    );
  };

  const resetCart = () => {
    setItems(items.map((item) => ({ ...item, quantity: 0 })));
  };

  const totalPrice = items.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  return (
    <div style={styles.page}>
      <h1 style={styles.heading}>🛍️ Shopping Cart</h1>

      <div style={styles.cart}>
        {items.map((item) => (
          <CartItem
            key={item.id}
            item={item}
            increment={increment}
            decrement={decrement}
            resetItem={resetItem}
          />
        ))}
      </div>

      <h2 style={styles.total}>Total Amount: ${totalPrice}</h2>

      <div style={{ textAlign: "center" }}>
        <button style={styles.resetAllBtn} onClick={resetCart}>
          Reset Cart
        </button>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "linear-gradient(to right, #77aec9, #a7d0bc)" ,
    padding: "30px",
  },
  heading: {
    textAlign: "center",
    color: "#ffffff",
    marginBottom: "30px",
  },
  cart: {
    display: "flex",
    justifyContent: "center",
    gap: "20px",
    flexWrap: "wrap",
  },
  total: {
    textAlign: "center",
    margin: "30px auto",
    background: "#ffffff",
    padding: "12px",
    width: "280px",
    borderRadius: "12px",
    color: "#57356e",
    fontWeight: "bold",
  },
  resetAllBtn: {
    background: "#E8F1F0",
    border: "none",
    padding: "10px 22px",
    borderRadius: "10px",
    cursor: "pointer",
    fontSize: "16px",
  },
};
export default Cart;
