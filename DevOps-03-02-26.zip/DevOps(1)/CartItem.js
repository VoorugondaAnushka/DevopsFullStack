import React from "react";

function CartItem({ item, increment, decrement, resetItem }) {
  return (
    <div style={styles.card}>
      <h3 style={{ color: "#355F6E" }}>{item.name}</h3>
      <p>Price: ${item.price}</p>
      <p>Quantity: {item.quantity}</p>

      <div>
        <button
          style={styles.addBtn}
          onClick={() => increment(item.id)}
        >
          +
        </button>

        <button
          style={styles.removeBtn}
          onClick={() => decrement(item.id)}
          disabled={item.quantity === 0}
        >
          -
        </button>

        <button
          style={styles.resetBtn}
          onClick={() => resetItem(item.id)}
        >
          Reset
        </button>
      </div>
    </div>
  );
}

const styles = {
  card: {
    background: "#F6FBFA",
    padding: "20px",
    borderRadius: "16px",
    width: "220px",
    textAlign: "center",
    boxShadow: "0 8px 16px rgba(0,0,0,0.15)",
  },
  addBtn: {
    background: "#B8E6D3",
    color: "#000000",
    border: "none",
    padding: "8px 14px",
    marginRight: "6px",
    borderRadius: "8px",
    cursor: "pointer",
  },
  removeBtn: {
    background: "#E6D9FF",
    color: "#000000",
    border: "none",
    padding: "8px 14px",
    marginRight: "6px",
    borderRadius: "8px",
    cursor: "pointer",
  },
  resetBtn: {
    background: "#bde5e1",
    border: "none",
    padding: "8px 14px",
    borderRadius: "8px",
    cursor: "pointer",
  },
};
export default CartItem;
